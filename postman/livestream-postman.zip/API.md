# API

Base URL khi chạy local: `http://localhost:8080`.

Realtime dùng duy nhất `/api/ws`; xem [REALTIME.md](REALTIME.md) cho protocol,
quyền và ví dụ. HTTP bên dưới dùng `Authorization: Bearer <JWT>` ở route bảo vệ.
User phải verified/active; không tin user_id/seller_id từ request body.
FE không polling HTTP để đọc live, sản phẩm, bình luận hay báo phí.

## Tài khoản

| Method | Route | Body / định dạng | JWT |
| --- | --- | --- | --- |
| POST | `/api/users/register` | `username`, `email`, `password` | Không |
| POST | `/api/users/verify` | `email`, `code` | Không |
| POST | `/api/users/login` | `email`, `password` | Không |
| POST | `/api/users/password/reset-request` | `email` | Không |
| POST | `/api/users/password/reset` | `email`, `code`, `new_password` | Không |
| PUT | `/api/users/me` | `fullname`, `avatar` | Có |
| POST | `/api/users/me/avatar` | multipart field `file` | Có |

Avatar nhận JPG/JPEG/PNG/WebP, request tối đa 10 MB. Response trả `url` bắt đầu
bằng `/uploads/`, có thể GET trực tiếp. Profile và avatar chỉ cập nhật tài khoản
đang đăng nhập.

OTP reset được hash và lưu riêng với OTP xác thực email, hết hạn sau 15 phút và
chỉ dùng một lần. Reset yêu cầu tài khoản đã xác thực. Cần cấu hình
`BREVO_API_KEY` và `FROM_EMAIL`; reset-request trả `502 email_delivery_failed`
nếu dịch vụ email chưa cấu hình hoặc gửi thất bại.

## Sản phẩm

| Method | Route | Công dụng | JWT |
| --- | --- | --- | --- |
| GET | `/api/products` | Danh sách, phân trang và tìm kiếm | Không |
| GET | `/api/products/:product_id` | Chi tiết sản phẩm | Không |
| POST | `/api/products` | Tạo sản phẩm | Có |
| PATCH | `/api/products/:product_id` | Sửa thông tin sản phẩm | Có |
| POST | `/api/products/:product_id/stock` | Điều chỉnh kho gốc | Có |
| DELETE | `/api/products/:product_id` | Xóa sản phẩm chưa được sử dụng | Có |

Tạo sản phẩm:

```json
{
  "name": "Áo thun",
  "price": 150000,
  "stock_quantity": 20,
  "image_url": "https://example.com/ao-thun.jpg",
  "description": "Áo cotton",
  "parcel": {"weight_grams":500,"length_cm":20,"width_cm":15,"height_cm":10}
}
```

`name`, `price`, `stock_quantity` bắt buộc. `seller_id` tự lấy từ JWT.
Tên sau khi bỏ khoảng trắng hai đầu phải khác rỗng; tên, mô tả và URL ảnh tối
đa 255 ký tự. Giá từ 0 đến 99,999,999.99, tối đa 2 chữ số thập phân. Kho ban đầu
không âm. Ảnh/mô tả là tùy chọn; ảnh nhận URL HTTP/HTTPS hoặc đường dẫn
`/uploads/...`. ProductService chỉ lưu URL ảnh, không tải file từ URL.

Create trả 201; detail/update/stock trả 200. JSON trả các trường `id`,
`seller_id`, `name`, `price`, `stock_quantity`, `image_url`, `description`,
`created_at`, không trả object User hoặc thông tin xác thực của người bán.

Danh sách nhận `page` (mặc định 1, tối đa 1,000,000), `page_size` (mặc định 20,
tối đa 100), `seller_id` (UUID), `q` (tìm một phần tên, tối đa 100 ký tự)
và `in_stock=true` để chỉ lấy sản phẩm còn hàng trong kho gốc.
Sắp xếp mới nhất trước, theo `created_at DESC, id DESC`. Các ký tự `%`, `_`, `!`
trong `q` được tìm như ký tự thường, không phải wildcard SQL.

```text
GET /api/products?seller_id=<UUID>&page=1&page_size=20&q=ao&in_stock=true
```

Response danh sách: `{ "data": [...], "total": 42, "page": 1, "page_size": 20 }`.
Không có kết quả trả `data: []`, `total: 0`.

PATCH chỉ nhận các trường cần sửa trong `name`, `price`, `image_url`,
`description`, `parcel`. Giá 0 và chuỗi rỗng cho ảnh/mô tả được lưu đúng; không cho sửa
owner hoặc ghi đè kho qua PATCH. Body rỗng, nhiều JSON object liên tiếp, trường
không hỗ trợ và request JSON quá 64 KB bị từ chối với 400.

Điều chỉnh kho dùng `{ "quantity_delta": 5 }` để nhập thêm 5 hoặc
`{ "quantity_delta": -2 }` để rút 2. Delta phải khác 0; không được làm âm kho
hoặc tràn số. Đây là thao tác cộng/trừ, mỗi request thành công đều được áp dụng
một lần; không tự retry request chưa rõ kết quả. Transaction khóa cùng dòng
sản phẩm với thao tác đặt hàng và cấp/trả kho live, để các cập nhật đồng thời
không ghi đè nhau. `stock_quantity` chỉ là kho gốc còn tự do, không bao gồm số
đã chuyển sang live hay đã giữ cho đơn hàng.

Chỉ chủ sản phẩm được sửa, điều chỉnh kho hoặc xóa (người khác nhận 403).
Xóa thành công trả 204; sản phẩm đang gắn trong live hoặc đã được tham chiếu
bởi bất kỳ OrderItem nào trả `409 product_in_use`, kể cả đơn đã hủy/hoàn, để
giữ lịch sử. Không tự xóa dây chuyền các đơn/live. Sửa giá/thông tin sản phẩm
gốc không thay đổi giá đã chốt trong đơn hoặc snapshot sản phẩm đã gắn vào live.

## Đơn hàng

Tất cả route bên dưới yêu cầu JWT.

| Method | Route | Body | Thành công |
| --- | --- | --- | --- |
| GET | `/api/orders` | Query `channel`, `status`, `page`, `page_size` | 200 |
| GET | `/api/orders/:order_id` | Không cần | 200 |
| GET | `/api/sales/offline` | Query `status`, `page`, `page_size` | 200 |
| GET | `/api/sales/offline/:order_id` | Không cần | 200 |
| POST | `/api/orders` | `product_id`, `quantity`, `payment_method`, `delivery`, tùy chọn `livestream_id` | 201 |
| POST | `/api/orders/:order_id/pay` | `payment_method` | 200 |
| POST | `/api/orders/:order_id/cancel` | Không cần | 200 |
| POST | `/api/orders/:order_id/refund` | `refund_reason` | 200 |

Ví dụ tạo đơn:

```json
{
  "product_id": "<UUID sản phẩm>",
  "quantity": 2,
  "payment_method": "manual",
  "livestream_id": "<UUID live, bỏ trường này nếu mua thông thường>",
  "delivery": {
    "name": "Người nhận", "phone": "0901234567", "province_code": "1",
    "ward": "Phường nơi nhận", "address_line": "Số nhà, tên đường"
  }
}
```

Response có `order_id`, `total_amount`, `status: "pending"`. Số lượng phải lớn
hơn 0. Đơn offline là đơn mua từ danh mục ngoài livestream. Bỏ `livestream_id`
để áp dụng giá và trừ kho gốc. Khi có `livestream_id`, phiên phải đang `start`
và có sản phẩm được gắn vào. Đơn áp dụng `discount_price` và trừ kho của live.
Sản phẩm gốc được tạo qua `POST /api/products`.

`GET /api/orders` chỉ trả đơn của người mua đang đăng nhập. `channel` nhận
`offline` hoặc `live`, mặc định trả cả hai. `GET /api/sales/offline` trả đơn
ngoài live có các sản phẩm thuộc người bán đang đăng nhập. Cả hai danh sách
nhận `status=pending|paid|cancelled|refunded` và dùng phân trang như danh mục.
Thứ tự là `created_at DESC, id DESC`. Bản ghi gồm `id`, `livestream_id`,
`total_amount`, `status`, `refund_reason`, `created_at` và `updated_at`.

Các endpoint chi tiết thêm `items` với `product_id`, `name`, `image_url`,
`quantity` và `price_at_purchase`. Tên và ảnh lấy từ danh mục hiện tại.
`payment` gồm `payment_method`, `status` và `amount`, hoặc `null` nếu bản ghi
thanh toán chưa có. Người bán xem đơn offline qua `/api/sales/offline`.
Người mua thực hiện các thao tác trên đơn qua `/api/orders`.

Người mua hủy đơn pending của mình; người bán xác nhận thanh toán/hoàn đơn của shop. Các chuyển trạng thái:

- `pending → paid`: thanh toán.
- `pending → cancelled`: hủy, trả lại tồn kho.
- `paid → refunded`: hoàn đơn, trả lại tồn kho và lưu lý do.

Order và Payment được cập nhật cùng transaction; thao tác lặp hoặc chuyển trạng
thái không hợp lệ bị từ chối. Các route pay/refund hiện chỉ ghi nhận trạng thái
nội bộ, **chưa thu tiền/hoàn tiền qua cổng thanh toán**.

## Tìm livestream

| Method | Route | Công dụng | JWT |
| --- | --- | --- | --- |
| GET | `/api/livestreams` | Tìm và lọc phiên live | Không |
| GET | `/api/livestreams/:livestream_id` | Chi tiết phiên live | Không |
| GET | `/api/livestreams/:livestream_id/products` | Danh sách sản phẩm trong live | Không |

Danh sách phiên nhận `q` (tìm theo tiêu đề, tối đa 100 ký tự), `seller_id` (UUID),
`product_id` (UUID sản phẩm được gắn), `status=start|end|all` và
`sort=newest|oldest`. Mặc định là `start` và `newest`. Thứ tự dùng `started_at`
và `id` để phân trang ổn định khi hai phiên có cùng thời gian. Ví dụ
`GET /api/livestreams?q=ao&status=start&sort=newest&page=1&page_size=20`.

Danh sách live và danh sách sản phẩm trong live dùng `{data, total, page, page_size}`
với mặc định trang 1, 20 bản ghi mỗi trang và tối đa 100 bản ghi mỗi trang.
Chi tiết live trả `id`, `seller_id`, `seller_username`, `seller_avatar`, `title`,
`status`, `started_at` và `ended_at`. Sản phẩm trong live trả `id`, `product_id`,
`name`, `image_url`, `description`, `original_price`, `discount_price`,
`stock_quantity` và `is_pinned`. Sản phẩm ghim đứng đầu. Dùng `product_id` khi
đặt đơn. Live đã kết thúc vẫn đọc được theo ID, còn đặt đơn yêu cầu live đang mở.

## Quản lý sản phẩm trong live

Các route ghi yêu cầu JWT. Chỉ chủ live được thao tác và chỉ được thêm sản
phẩm thuộc tài khoản đó.

| Method | Route | Body | Thành công |
| --- | --- | --- | --- |
| POST | `/api/livestreams/:livestream_id/products` | `product_id`, `discount_price`, `stock_quantity`, tùy chọn `is_pinned` | 201 |
| DELETE | `/api/livestreams/:livestream_id/products/:product_id` | Không cần | 204 |

`stock_quantity > 0`, `discount_price >= 0`. Thêm sản phẩm chuyển lượng hàng này
từ kho sản phẩm gốc sang phần kho dành riêng cho live, đồng thời sao chép tên,
ảnh, mô tả và giá gốc. Không được thêm trùng hoặc thêm vào live đã kết thúc.
Xóa trả lại phần hàng chưa bán; bị chặn nếu còn đơn `pending` hoặc `paid` liên
quan, để các đơn đó vẫn có thể hủy/hoàn đúng kho.

Tạo/kết thúc live dùng `live.create`/`live.end`, theo REALTIME.md. Live mới lưu
ended_at=NULL. `live.subscribe` đọc được snapshot của phiên đã kết thúc;
gửi bình luận/đặt mua trên phiên đó vẫn bị chặn.

Khi kết thúc live, kho chưa bán được trả về kho gốc trong cùng transaction.
Hủy hoặc hoàn đơn sau đó trả hàng về kho gốc. Gửi lại `live.end` giữ nguyên
`ended_at` và không trả kho lần nữa. Với phiên đã kết thúc trước bản cập nhật,
gửi lại `live.end` từ tài khoản chủ live để trả phần kho còn giữ.

## Bình luận trong live

Dùng `comments.subscribe`/`comments.send` qua `/api/ws`; không có HTTP comments.
MongoDB lưu nội dung, SQL giữ quan hệ/trạng thái live. Lịch sử/cursor, bảo vệ
sender và reconnect được mô tả trong [REALTIME.md](REALTIME.md).

## Video qua LiveKit

| Method | Route | Body | JWT |
| --- | --- | --- | --- |
| POST | `/api/livestreams/:livestream_id/media-token` | `{"role":"publisher"}` hoặc `{"role":"viewer"}` | Có |
| POST | `/api/livestreams/:livestream_id/end` | Không cần | Có |

Token media trả `{ "url": "wss://…", "token": "…" }`, có hiệu lực 90 giây
để bắt đầu kết nối và chỉ dùng cho phòng được chỉ định. Chỉ chủ phiên được
lấy token phát camera/micro. Người xem chỉ được nhận media. Mỗi lượt xem có
identity riêng để nhiều tab có thể xem song song. Live đã kết thúc trả `409`,
người phát sai quyền nhận `403`, cấu hình LiveKit bị thiếu trả `503`.

Kết thúc phiên vẫn hỗ trợ lệnh WebSocket `live.end`. Cả hai đường đều cập nhật
trạng thái, trả kho và yêu cầu LiveKit ngắt phòng. `media_closed: false` cho
biết phiên đã kết thúc trong Go nhưng LiveKit chưa xác nhận đóng phòng. Chủ
phiên có thể gọi lại endpoint kết thúc. Trên bản LiveKit tự host, token cũ
có thể dùng lại đến khi hết hạn để kết nối, tùy cấu hình LiveKit. Backend chặn
cấp token mới cho phiên đã kết thúc.

### Chạy local trên Windows

1. Tải `livekit-server.exe` từ [LiveKit Releases](https://github.com/livekit/livekit/releases)
   và chạy `.\livekit-server.exe --dev` trong PowerShell.
2. Thêm vào `.env` của backend rồi khởi động lại Go.

   ```dotenv
   LIVEKIT_URL=ws://127.0.0.1:7880
   LIVEKIT_API_KEY=devkey
   LIVEKIT_API_SECRET=secret
   ```

3. Mở frontend tại `http://localhost:5173`, đăng nhập và tạo phiên. Mở cửa sổ
   ẩn danh bằng tài khoản thứ hai để xem trực tiếp trên cùng máy.

Dùng HTTPS cho frontend và WSS cho LiveKit khi phát từ điện thoại hoặc qua
Internet. `LIVEKIT_URL` phải truy cập được từ trình duyệt. Có thể đặt
`LIVEKIT_API_URL` thành origin HTTP(S) nội bộ cho các lệnh quản lý phòng nếu
khác origin client. Chỉ lưu API key và secret ở backend. Cặp `devkey`/`secret`
dành cho localhost. Xem [cổng và firewall của LiveKit](https://docs.livekit.io/transport/self-hosting/ports-firewall/)
khi tự host qua Internet.

## Lỗi

- 400: body/UUID/phân trang/sản phẩm/số lượng/giá/OTP không hợp lệ hoặc OTP hết hạn.
- 401: chưa đăng nhập hoặc JWT không hợp lệ.
- 403: không sở hữu live hoặc sản phẩm cần thao tác.
- 404: không có tài nguyên; đơn không thuộc user hiện tại cũng trả 404.
- 409: thiếu kho, trùng sản phẩm, trạng thái live/đơn không phù hợp, sản phẩm còn đơn đang xử lý hoặc sản phẩm gốc còn tham chiếu live/đơn.
- 500: lỗi nội bộ, không trả chi tiết SQL ra client.
- 502: gửi email reset thất bại.

## Kiểm tra tích hợp

```sh
TEST_MYSQL_DSN='user:password@tcp(127.0.0.1:3306)/livestream_test?charset=utf8mb4&parseTime=True&loc=Local' go test -v ./...
```

Dùng database thử nghiệm riêng. Test chạy HTTP/WebSocket với MySQL thực, tự
migrate schema và dọn các fixture UUID vừa tạo. Các fixture sản phẩm được tạo
qua API, không chèn trực tiếp vào DB. Bao phủ CRUD sản phẩm, lọc/tìm kiếm/phân
trang, quyền sở hữu, chặn xóa khi còn tham chiếu, điều chỉnh kho đồng thời,
giới hạn giá/kho, JWT, profile/avatar,
quyền sở hữu, chuyển trạng thái đơn, tồn kho khi mua đồng thời, tạo live và
quản lý sản phẩm trong live, OTP reset hết hạn/sai/dùng lại. Test email cố ý bỏ
API key để kiểm tra lỗi cấu hình và dùng OTP fixture cho bước xác nhận; không
gửi email thực. Không cần Redis/MongoDB cho suite API này. Khi không đặt
`TEST_MYSQL_DSN`, integration suite được skip.


## Checkout và báo phí GHN

Xem [SHIPPING.md](SHIPPING.md) cho cấu hình GHN staging, dữ liệu kiện/khu vực,
contract báo giá và giới hạn chỉ lấy phí. Checkout dùng địa chỉ đầy đủ và mã
khu vực GHN; chủ live không đặt phí nội tỉnh/liên tỉnh. Backend chỉ gọi danh
mục và API fee, không tạo vận đơn hay đặt lịch lấy hàng.

## Vị trí hiện tại và nơi lấy hàng của phiên live

`DeliveryAddress` có thêm `location_mode: "manual" | "current"` (tùy chọn cho
client cũ). Chế độ `current` bắt buộc cả latitude và longitude, cùng địa chỉ
đủ tên/điện thoại/tỉnh/phường/đường. Tọa độ GPS không thay tên/số điện thoại
hoặc số căn hộ; người dùng kiểm tra và bổ sung nếu dữ liệu bản đồ chưa đủ.

`POST /api/delivery/reverse-geocode` cần JWT, body:

```json
{"latitude":21.028511,"longitude":105.804817}
```

Response 200 có `address` gồm location_mode=current, province_code/name, ward,
address_line, latitude/longitude và `attribution`. Tên/điện thoại được giữ trên
FE, không gửi đến dịch vụ bản đồ. Tỉnh cũ từ provider được ánh xạ về danh mục
34 tỉnh hiện tại. Ngoài Việt Nam/không xác định tỉnh trả 400
`location_not_supported`; tọa độ thiếu/sai trả 400 `invalid_coordinates`;
lỗi dịch vụ trả 503 `geocoding_unavailable`. Không tự dùng địa chỉ cũ khi GPS
thất bại: FE yêu cầu thử lại hoặc chủ động chọn Nhập địa chỉ.

Backend mặc định gọi Nominatim/OpenStreetMap, tối đa một request/giây trong
một tiến trình, cache tối đa 256 vị trí trong 10 phút. Có thể cấu hình
`GEOCODING_REVERSE_URL` trỏ đến dịch vụ reverse tương thích Nominatim; cần
khởi động lại backend sau khi đổi. Nếu chạy nhiều instance hoặc lưu lượng
cao, dùng dịch vụ riêng/thích hợp thay vì public endpoint. FE giữ attribution
OpenStreetMap. Reverse geocoding và tile maps đều cần Internet.

Hai API sau cần JWT **chủ phiên**, không xuất địa chỉ qua danh sách/chi tiết
live công khai:

- `GET /api/livestreams/:id/pickup`: `{pickup_address: ...}`; nếu chưa có nơi
  riêng thì dùng địa chỉ shop để điền sẵn, hoặc null khi shop chưa cấu hình.
- `PUT /api/livestreams/:id/pickup`: body `{pickup_address: DeliveryAddress}`.
  Lưu địa chỉ cho phiên đang mở; người khác nhận 403, phiên kết thúc nhận 409.

Khi bắt đầu phát, FE mặc định lấy GPS mới, tự điền địa chỉ và xin người bán
kiểm tra/xác nhận. Sau khi lưu nơi lấy hàng mới, FE mới xin media token.
Có thể chuyển sang Nhập địa chỉ nếu không dùng GPS. Đây là vị trí tại thời
điểm bắt đầu phát, không phải theo dõi vị trí liên tục.

Checkout trong live dùng nơi lấy hàng của **phiên đó** để lấy báo phí hãng;
đơn ngoài live vẫn dùng địa chỉ shop. Phiên cũ chưa có địa chỉ riêng dùng
địa chỉ shop như trước. Cập nhật nơi phát không đổi địa chỉ shop hoặc snapshot
đã lưu trong đơn cũ. Migration thêm `livestream_pickups` và location_mode vào
các địa chỉ đã có; không cần tự xóa/tạo lại bảng.

### Báo phí và bưu cục

Các danh mục GHN, tra bưu cục và quote dùng lệnh `shipping.*` trên `/api/ws`.
Không có HTTP `/api/shipping/*`. Xem [SHIPPING.md](SHIPPING.md) và REALTIME.md.
PUT pickup/HTTP quote cũ được giữ cho client tương thích; FE dùng WS.
